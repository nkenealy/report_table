from setuptools import setup


setup(name='techtalk',
      version='0.1',
      description='Talks for Bloomberg Polarlake Client Services',
      author='Neil Kenealy',
      author_email='neilkenealy@gmail.com',
      packages=['demo'],
      )

__author__ = 'Neil Kenealy'
